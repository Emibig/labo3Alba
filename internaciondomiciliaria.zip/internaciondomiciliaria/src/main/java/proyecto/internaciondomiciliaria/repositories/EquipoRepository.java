package proyecto.internaciondomiciliaria.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import proyecto.internaciondomiciliaria.connectors.*;
import proyecto.internaciondomiciliaria.entities.Equipo;

public class EquipoRepository {

    private Connection conn = Connector.getConnection();

    public void save(Equipo equipo) {
        if (equipo == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into equipos ( descripcion, codigo_interno, cantidad) values (?,?,?)",

                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, equipo.getDescripcion());
            ps.setInt(2, equipo.getCodigo_interno());
            ps.setInt(3, equipo.getCantidad());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                equipo.setId_equipo(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void remove(Equipo equipo) {
        if (equipo == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement("delete from equipos where id_equipo=?")) {
            ps.setInt(1, equipo.getId_equipo());
            ps.execute();
        } catch (Exception e) {
            System.out.print(e);
        }
    };

    public void update(Equipo equipo) {
        if (equipo == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "update equipos set id_paciente = ?, descripcion=?, codigo_interno=?, cantidad=? where id_equipo=?")) {
            ps.setInt(1, equipo.getId_paciente());
            ps.setString(2, equipo.getDescripcion());
            ps.setInt(3, equipo.getCodigo_interno());
            ps.setInt(4, equipo.getCantidad());

            ps.setInt(5, equipo.getId_equipo());
            ps.execute();
        } catch (Exception e) {
            System.out.print(e);
        }
    };

    public List<Equipo> getAll() {
        List<Equipo> list = new ArrayList<Equipo>();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from equipos")) {
            while (rs.next()) {
                list.add(new Equipo(
                        rs.getInt("id_equipo"), // id_equipo
                        rs.getInt("id_paciente"),
                        rs.getString("descripcion"), // descripcion
                        rs.getInt("codigo_interno"), // codigo interno del equipo
                        rs.getInt("cantidad") // cantidad

                ));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public Equipo getByEquipoId(int id_descripcion) {
        return getAll()
                .stream()
                .filter(c -> c.getId_equipo() == id_descripcion)
                .findFirst()
                .orElse(new Equipo());
    }

    public List<Equipo> getLikeEquipoDescripcion(String Descripcion) {
        if (Descripcion == null)
            return new ArrayList<Equipo>();
        return getAll()
                .stream()
                .filter(c -> c.getDescripcion().toLowerCase().contains(Descripcion.toLowerCase()))
                .toList();
    }

    public Equipo getByEquipoCodigoInterno(int codigo_interno) {
        return getAll()
                .stream()
                .filter(a -> a.getCodigo_interno() == codigo_interno)
                .findFirst()
                .orElse(new Equipo());
    }

    // filtra por nombre(paciente) y equipo
    public List<Equipo> getLikeEquipoAndIdPaciente(int id_paciente, String descripcion) {
        if (descripcion == null)
            return new ArrayList<Equipo>();
        return getAll()
                .stream()
                .filter(a -> a.getId_paciente() == id_paciente
                        && a.getDescripcion().contains(descripcion))
                .sorted(Comparator.comparing(Equipo::getDescripcion))
                .collect(Collectors.toList());
    }

    // total de id equipos que tiene un mismo id paciente
    public Map<Integer, Integer> getLikeEquipoTotalPorIdPaciente(int id_paciente) {
        return getAll()
                .stream()
                .filter(e -> e.getId_paciente() == id_paciente)
                .collect(Collectors.groupingBy(Equipo::getId_paciente,
                        Collectors.summingInt(e -> 1)));
    }

}
