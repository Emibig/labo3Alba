package proyecto.internaciondomiciliaria.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import proyecto.internaciondomiciliaria.connectors.*;
import proyecto.internaciondomiciliaria.enums.Horario;
import proyecto.internaciondomiciliaria.entities.Visita;

public class VisitaRepository {
    private Connection conn = Connector.getConnection();

    public void save(Visita visita) {
        if (visita == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into visitas (id_chofer, nombre_chofer,id_paciente, zona,fecha, hora_inicio, hora_fin,coordinado, concretado) values (?,?,?,?,?,?,?,?,?)",

                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, visita.getId_chofer());
            ps.setString(2, visita.getNombre_chofer());
            ps.setInt(3, visita.getId_paciente());
            ps.setString(4, visita.getZona());
            ps.setString(5, visita.getFecha());
            ps.setString(6, visita.getHora_inicio() + "");
            ps.setString(7, visita.getHora_fin() + "");
            ps.setString(8, visita.getCoordinado());
            ps.setString(9, visita.getConcretado());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                visita.setId_visita(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void remove(Visita visita) {
        if (visita == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement("delete from visitas where id_visita=?")) {
            ps.setInt(1, visita.getId_visita());
            ps.execute();
        } catch (Exception e) {
            System.out.print(e);
        }
    };

    public void update(Visita visita) {
        if (visita == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "update visitas set id_chofer =?,nombre_chofer =?,id_paciente =?, zona =?, fecha=?, hora_inicio=?, hora_fin=?, coordinado=?, concretado=? where id_visita=?")) {
            ps.setInt(1, visita.getId_chofer());
            ps.setString(2, visita.getNombre_chofer());
            ps.setInt(3, visita.getId_paciente());
            ps.setString(4, visita.getZona());
            ps.setString(5, visita.getFecha());
            ps.setString(6, visita.getHora_inicio() + "");
            ps.setString(7, visita.getHora_fin() + "");
            ps.setString(8, visita.getCoordinado());
            ps.setString(9, visita.getConcretado());
            ps.setInt(10, visita.getId_visita());
            ps.execute();
        } catch (Exception e) {
            System.out.print(e);
        }
    };

    public List<Visita> getAll() {
        List<Visita> list = new ArrayList<Visita>();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from visitas")) {
            while (rs.next()) {
                list.add(new Visita(
                        rs.getInt("id_visita"),
                        rs.getInt("id_chofer"),
                        rs.getString("nombre_chofer"),
                        rs.getInt("id_paciente"),
                        rs.getString("zona"),
                        rs.getString("fecha"),
                        Horario.valueOf(rs.getString("hora_inicio")),
                        Horario.valueOf(rs.getString("hora_fin")),
                        rs.getString("coordinado"),
                        rs.getString("concretado")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public Visita getByVisitaId(int id_visita) {
        return getAll()
                .stream()
                .filter(a -> a.getId_visita() == id_visita)
                .findAny()
                .orElse(new Visita());
    }

    public List<Visita> getByVisitaFecha(String fecha) {
        if (fecha == null)
            return new ArrayList<Visita>();
        return getAll()
                .stream()
                .filter(a -> a.getFecha().contains(fecha))
                .collect(Collectors.toList());
    }

    // fecha y zona
    public List<Visita> getByVisitaFechaAndZona(String fecha, String zona) {
        if (fecha == null || zona == null)
            ;
        return getAll()
                .stream()
                .filter(a -> a.getFecha().contains(fecha)
                        && a.getZona().contains(zona))
                .collect(Collectors.toList());
    }

    // filtra por coordinada (estado coordinado) y zona

    public List<Visita> getLikeVisitaCoordinadaPorZona(String zona, String coordinado) {
        if (zona == null || coordinado == null)
            return new ArrayList<Visita>();
        return getAll()
                .stream()
                .filter(a -> a.getZona().toLowerCase().contains(zona.toLowerCase())
                        && a.getCoordinado().contains(coordinado.toLowerCase()))
                .collect(Collectors.toList());
    }

    // filtra por coordinada (estado coordinado) y concretado/pendiente

    public List<Visita> getLikeVisitaConcretada(String coordinada, String concretada) {
        if (coordinada == null || concretada == null)
            return new ArrayList<Visita>();
        return getAll()
                .stream()
                .filter(a -> a.getCoordinado().toLowerCase().contains(coordinada)
                        && a.getConcretado().contains(concretada))
                .collect(Collectors.toList());
    }

    public List<Visita> getByVisitaHorarioInicioFin(Horario horario_inicio,
            Horario horario_fin) {
        if (horario_inicio == null || horario_fin == null)
            return new ArrayList<Visita>();
        return getAll()
                .stream()
                .filter(a -> a.getHora_inicio().name().contains(horario_inicio.name())
                        && a.getHora_fin().name().contains(horario_fin.name()))
                .collect(Collectors.toList());

    }

    public List<Visita> getByVisitaHorarioInicio(Horario horario_inicio) {
        if (horario_inicio == null)
            return new ArrayList<Visita>();
        return getAll()
                .stream()
                .filter(a -> a.getHora_inicio().name().contains(horario_inicio.name()))
                .collect(Collectors.toList());
    }

}
