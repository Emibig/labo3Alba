package proyecto.internaciondomiciliaria.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import proyecto.internaciondomiciliaria.connectors.*;
import proyecto.internaciondomiciliaria.entities.Paciente;

public class PacienteRepository {

    private Connection conn = Connector.getConnection();

    public void save(Paciente paciente) {
        if (paciente == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into pacientes (nombre, nro_socio, cliente, celular, calle_altura, piso_departamento, entrecalles, localidad,zona) values (?,?,?,?,?,?,?,?,?)",

                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, paciente.getNombre());
            ps.setInt(2, paciente.getNro_socio());
            ps.setString(3, paciente.getCliente());
            ps.setInt(4, paciente.getCelular());
            ps.setString(5, paciente.getCalle_altura());
            ps.setString(6, paciente.getPiso_departamento());
            ps.setString(7, paciente.getEntrecalles());
            ps.setString(8, paciente.getLocalidad());
            ps.setString(9, paciente.getZona());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                paciente.setId_paciente(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void remove(Paciente paciente) {
        if (paciente == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement("delete from pacientes where id_paciente=?")) {
            ps.setInt(1, paciente.getId_paciente());
            ps.execute();
        } catch (Exception e) {
            System.out.print(e);
        }
    };

    public void update(Paciente paciente) {
        if (paciente == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "update pacientes set nombre=?, nro_socio=?, cliente=?, celular=?, calle_altura=?, piso_departamento=?, entrecalles=?, localidad=?,zona=? where id_paciente=?")) {
            ps.setString(1, paciente.getNombre());
            ps.setInt(2, paciente.getNro_socio());
            ps.setString(3, paciente.getCliente());
            ps.setInt(4, paciente.getCelular());
            ps.setString(5, paciente.getCalle_altura());
            ps.setString(6, paciente.getPiso_departamento());
            ps.setString(7, paciente.getEntrecalles());
            ps.setString(8, paciente.getLocalidad());
            ps.setString(9, paciente.getZona());
            ps.setInt(10, paciente.getId_paciente());
            ps.execute();
        } catch (Exception e) {
            System.out.print(e);
        }
    };

    public List<Paciente> getAll() {
        List<Paciente> list = new ArrayList<Paciente>();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from pacientes")) {
            while (rs.next()) {
                list.add(new Paciente(
                        rs.getInt("id_paciente"),
                        rs.getString("nombre"),
                        rs.getInt("nro_socio"),
                        rs.getString("cliente"),
                        rs.getInt("celular"),
                        rs.getString("calle_altura"),
                        rs.getString("piso_departamento"),
                        rs.getString("entrecalles"),
                        rs.getString("localidad"),
                        rs.getString("zona")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public Paciente getByPacienteId(int id_paciente) {
        return getAll()
                .stream()
                .filter(a -> a.getId_paciente() == id_paciente)
                .findAny()
                .orElse(new Paciente());
    }

    public List<Paciente> getLikePacienteNombre(String nombre) {
        if (nombre == null)
            return new ArrayList<Paciente>();
        return getAll()
                .stream()
                .filter(a -> a.getNombre().toLowerCase().contains(nombre.toLowerCase()))
                .collect(Collectors.toList());
    }

    public Paciente getByPacienteNroSocio(int nro_socio) {
        return getAll()
                .stream()
                .filter(a -> a.getNro_socio() == nro_socio)
                .findAny()
                .orElse(new Paciente());

    }

    /* filtra por nombre (paciente) y cliente (prepaga) */
    public List<Paciente> getLikePacienteNombreAndCliente(String nombre, String cliente) {
        if (nombre == null || cliente == null)
            return new ArrayList<Paciente>();
        return getAll()
                .stream()
                .filter(a -> a.getNombre().toLowerCase().contains(nombre.toLowerCase())
                        && a.getCliente().toLowerCase().contains(cliente.toLowerCase()))
                .collect(Collectors.toList());
    }

    // filtra por nombre(paciente) y zona, ordena por zona
    public List<Paciente> getLikePacienteNombreAgrupadoZona(String nombre, String zona) {
        if (nombre == null || zona == null)
            return new ArrayList<Paciente>();
        return getAll()
                .stream()
                .filter(a -> a.getNombre().toLowerCase().contains(nombre.toLowerCase())
                        && a.getZona().contains(zona))
                .sorted(Comparator.comparing(Paciente::getZona))
                .collect(Collectors.toList());
    }

    public List<Paciente> getLikeCliente(String cliente) {
        if (cliente == null)
            return new ArrayList<Paciente>();
        return getAll()
                .stream()
                .filter(a -> a.getCliente().toLowerCase().contains(cliente.toLowerCase()))
                .collect(Collectors.toList());
    }

    public List<Paciente> getLikeCelular(int celular) {
        return getAll()
                .stream()
                .filter(a -> a.getCelular() == celular)
                .collect(Collectors.toList());
    }
                    
    }


