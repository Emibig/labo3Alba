SELECT*from equipos;
SELECT* from pacientes;
SELECT* from choferes;
SELECT * FROM visitas;
SELECT * FROM asignaciones_pacientes;

 -- veo cada paciente con su visita y chofer asignado, por zona 
SELECT  p.nombre, 
	p.calle_altura,
	p.localidad,
	p.zona, 
	c.nombre_chofer,
	c.vehiculo, 
	v.fecha,
	v.hora_inicio,
	v.hora_fin,
	v.coordinado,
	v.concretado
FROM visitas v
JOIN pacientes p 
ON v.zona = p.zona
INNER JOIN choferes c 
ON v.zona = c.zona
ORDER BY p.nombre ASC;

-- reviso que pacientes tienen cual equipo en que direccion       
select * from equipos;

SELECT p.nombre, p.id_paciente, p.calle_altura, e.descripcion, e.codigo_interno, e.id_equipo
FROM asignaciones_pacientes a
JOIN equipos e ON a.id_equipo = e.id_equipo
JOIN pacientes p ON a.id_paciente = p.id_paciente
WHERE p.id_paciente IS NOT NULL
ORDER BY id_paciente;

-- consultar los pacientes y equipos con la fecha de visita
SELECT
	p.zona zona,
    p.nombre paciente,
    e.descripcion,
	v.id_visita,
    v.fecha
FROM visitas v
JOIN pacientes p 
ON v.zona = p.zona
JOIN equipos e 
ON e.id_paciente = p.id_paciente
order by p.nombre asc;

-- cambiar el la direccion de un paciente 
SELECT nombre, calle_altura
FROM pacientes
WHERE nombre  = 'Bastista, Salomon';

UPDATE pacientes
SET calle_altura = 'Av Monroe 4500'
WHERE nombre = 'Bastista, Salomon';

-- ordenar las visitas por fecha y luego horario 
SELECT p.nombre,
	v.fecha, 
    v.coordinado,
	v.hora_inicio, 
    v.coordinado
FROM visitas v
INNER JOIN pacientes p
ON v.id_paciente = p.id_paciente
WHERE coordinado = 'OK';

select*from visitas;
     
-- consulto los pacientes que tienen vigente colchon de aire 
SELECT p.nombre, e.descripcion
FROM pacientes p
INNER JOIN equipos e
ON p.id_paciente = e.id_paciente
WHERE e.descripcion = 'Colchon de aire'; 

-- agrego cama ortopedica a los pacientes que ya tenian colchon de aire 
INSERT INTO equipos (id_paciente, descripcion, codigo_interno, cantidad)
SELECT p.id_paciente, 'Cama ortopedica con colchon hospitalario y juego de barandas','0101',1
FROM pacientes p
INNER JOIN equipos e ON p.id_paciente = e.id_paciente
WHERE e.descripcion = 'Colchon de aire';

SELECT p.id_paciente, p.nombre, COUNT(*) AS total_equipos
FROM pacientes p
JOIN equipos e ON p.id_paciente = e.id_paciente
GROUP BY p.id_paciente, p.nombre;
